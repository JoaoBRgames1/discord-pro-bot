# Servidor Para Hospedagem De Bots

Kit base para montar uma VPS dedicada a bots em Python, Node.js e outros runtimes.

## Ideia

- Cada bot roda em seu proprio container Docker.
- Bots sem painel web nao precisam expor porta.
- Bots com painel web podem expor uma porta interna.
- Portainer ajuda a gerenciar containers pelo navegador.
- Caddy pode fazer proxy com HTTPS para paineis web.

## Requisitos da VPS

Recomendado para comecar:

- Ubuntu ou Debian.
- 2 vCPU.
- 2 GB RAM ou mais.
- 20 GB SSD ou mais.
- Acesso SSH root ou usuario com sudo.
- Dominio opcional.

Para bots de musica, prefira 4 GB RAM e instale/embuta FFmpeg nos containers.

## Estrutura sugerida

```text
/opt/bots/
  docker-compose.yml
  .env
  caddy/
    Caddyfile
    data/
    config/
  apps/
    meu-bot-python/
    meu-bot-node/
```

## Instalacao rapida

No servidor:

```bash
sudo mkdir -p /opt/bots
sudo chown -R $USER:$USER /opt/bots
cd /opt/bots
```

Instale Docker:

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
```

Depois saia e entre no SSH novamente.

Copie os arquivos deste kit para `/opt/bots` e rode:

```bash
docker compose up -d
```

## Portainer

Depois de subir, acesse:

```text
http://IP_DA_VPS:9000
```

Crie o usuario administrador no primeiro acesso.

## Hospedando um bot Python

1. Copie `templates/python-bot` para `/opt/bots/apps/nome-do-bot`.
2. Coloque seu codigo dentro da pasta.
3. Configure o `.env` do bot.
4. Adicione o servico no `docker-compose.yml`.
5. Rode:

```bash
docker compose up -d --build nome-do-bot
```

## Hospedando um bot Node.js

1. Copie `templates/node-bot` para `/opt/bots/apps/nome-do-bot`.
2. Coloque seu codigo dentro da pasta.
3. Configure o `.env` do bot.
4. Adicione o servico no `docker-compose.yml`.
5. Rode:

```bash
docker compose up -d --build nome-do-bot
```

## Logs

Ver todos:

```bash
docker compose logs -f
```

Ver apenas um bot:

```bash
docker compose logs -f nome-do-bot
```

## Atualizar bot

```bash
cd /opt/bots
git pull
docker compose up -d --build nome-do-bot
```

## Dominios e paineis web

Para um bot com painel na porta interna `19071`, adicione no Caddy:

```text
painel.seudominio.com {
    reverse_proxy nome-do-bot:19071
}
```

Depois:

```bash
docker compose restart caddy
```

No DNS do dominio, crie:

```text
Tipo A
Nome painel
Valor IP_DA_VPS
```

## Segurança basica

- Nao publique `.env`.
- Use senhas fortes.
- Ative firewall liberando apenas SSH, HTTP, HTTPS e portas realmente necessarias.
- Rode cada bot com restart automatico.
- Prefira um banco externo ou volume persistente para dados importantes.

