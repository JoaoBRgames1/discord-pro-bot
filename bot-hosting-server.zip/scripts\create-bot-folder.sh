#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 2 ]; then
  echo "Uso: ./create-bot-folder.sh python|node nome-do-bot"
  exit 1
fi

runtime="$1"
name="$2"
target="/opt/bots/apps/$name"

mkdir -p /opt/bots/apps

case "$runtime" in
  python)
    cp -r /opt/bots/templates/python-bot "$target"
    ;;
  node)
    cp -r /opt/bots/templates/node-bot "$target"
    ;;
  *)
    echo "Runtime invalido. Use python ou node."
    exit 1
    ;;
esac

cp "$target/.env.example" "$target/.env"
echo "Criado em $target"
