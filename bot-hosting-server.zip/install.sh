#!/usr/bin/env bash
set -euo pipefail

echo "Atualizando sistema..."
apt update -y
apt upgrade -y

echo "Instalando pacotes base..."
apt install -y curl ca-certificates ufw nano git unzip

echo "Instalando Docker..."
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi

systemctl enable docker
systemctl start docker

echo "Criando estrutura..."
mkdir -p /opt/bots/apps
mkdir -p /opt/bots/templates/python-bot
mkdir -p /opt/bots/templates/node-bot/src
mkdir -p /opt/bots/caddy/data
mkdir -p /opt/bots/caddy/config

cat > /opt/bots/docker-compose.yml <<'EOF'
services:
  portainer:
    image: portainer/portainer-ce:latest
    container_name: portainer
    restart: unless-stopped
    ports:
      - "9000:9000"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - portainer_data:/data

  caddy:
    image: caddy:latest
    container_name: caddy
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./caddy/Caddyfile:/etc/caddy/Caddyfile
      - ./caddy/data:/data
      - ./caddy/config:/config

volumes:
  portainer_data:
EOF

cat > /opt/bots/caddy/Caddyfile <<'EOF'
:80 {
    respond "Bot hosting server online" 200
}

# Exemplo:
# painel.seudominio.com {
#     reverse_proxy portainer:9000
# }
#
# bot.seudominio.com {
#     reverse_proxy discord-pro-bot:19071
# }
EOF

cat > /opt/bots/templates/python-bot/Dockerfile <<'EOF'
FROM python:3.12-slim

ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1

WORKDIR /app

RUN apt-get update \
    && apt-get install -y --no-install-recommends ffmpeg ca-certificates \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "main.py"]
EOF

cat > /opt/bots/templates/python-bot/requirements.txt <<'EOF'
discord.py[voice]>=2.4.0
python-dotenv>=1.0.1
EOF

cat > /opt/bots/templates/python-bot/.env.example <<'EOF'
DISCORD_TOKEN=coloque_o_token_aqui
EOF

cat > /opt/bots/templates/python-bot/main.py <<'EOF'
import os

import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready() -> None:
    print(f"Bot conectado como {bot.user}")

@bot.command()
async def ping(ctx: commands.Context) -> None:
    await ctx.reply("pong")

bot.run(os.environ["DISCORD_TOKEN"])
EOF

cat > /opt/bots/templates/node-bot/Dockerfile <<'EOF'
FROM node:22-slim

WORKDIR /app

COPY package*.json ./
RUN npm ci --omit=dev

COPY . .

CMD ["node", "src/index.js"]
EOF

cat > /opt/bots/templates/node-bot/package.json <<'EOF'
{
  "name": "discord-node-bot",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "start": "node src/index.js"
  },
  "dependencies": {
    "discord.js": "^14.16.3",
    "dotenv": "^16.4.7"
  }
}
EOF

cat > /opt/bots/templates/node-bot/.env.example <<'EOF'
DISCORD_TOKEN=coloque_o_token_aqui
EOF

cat > /opt/bots/templates/node-bot/src/index.js <<'EOF'
import "dotenv/config";
import { Client, GatewayIntentBits } from "discord.js";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once("ready", () => {
  console.log(`Bot conectado como ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (message.content === "!ping") {
    await message.reply("pong");
  }
});

client.login(process.env.DISCORD_TOKEN);
EOF

cat > /opt/bots/README.md <<'EOF'
# Bot Hosting Server

Pasta principal:

/opt/bots

Comandos:

docker compose up -d
docker compose logs -f
docker compose ps

Portainer:

http://IP_DA_VPS:9000

Bots ficam em:

/opt/bots/apps
EOF

echo "Configurando firewall..."
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 9000/tcp
ufw allow 19071/tcp
ufw --force enable

echo "Subindo Portainer e Caddy..."
cd /opt/bots
docker compose up -d

echo ""
echo "Instalacao concluida."
echo "Acesse o painel:"
echo "http://IP_DA_SUA_VPS:9000"
echo ""
echo "Estrutura criada em /opt/bots"
