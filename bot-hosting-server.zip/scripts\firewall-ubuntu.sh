#!/usr/bin/env bash
set -euo pipefail

sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 9000/tcp
sudo ufw enable
sudo ufw status verbose

