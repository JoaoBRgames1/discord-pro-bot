import discord
from discord.ext import commands

from bot.config import Settings
from bot.database import Database


class ProBot(commands.Bot):
    def __init__(self, settings: Settings, database: Database) -> None:
        intents = discord.Intents.default()
        intents.guilds = True
        intents.members = True
        intents.message_content = True
        intents.voice_states = True
        super().__init__(command_prefix="!", intents=intents)
        self.settings = settings
        self.database = database

    async def setup_hook(self) -> None:
        await self.load_extension("bot.cogs.moderation")
        await self.load_extension("bot.cogs.automation")
        await self.load_extension("bot.cogs.music")
        await self.tree.sync()

    async def on_ready(self) -> None:
        guilds = ", ".join(guild.name for guild in self.guilds)
        print(f"Bot conectado como {self.user} | Servidores: {guilds}")


def create_bot(settings: Settings, database: Database) -> ProBot:
    return ProBot(settings, database)
