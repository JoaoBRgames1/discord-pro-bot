from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import aiosqlite


@dataclass
class GuildConfig:
    guild_id: int
    autorole_id: int | None = None
    mod_log_channel_id: int | None = None
    welcome_channel_id: int | None = None
    welcome_message: str = "Bem-vindo(a), {member}!"
    music_enabled: bool = True
    moderation_enabled: bool = True


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.conn: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row

    async def migrate(self) -> None:
        db = self._db
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS guild_configs (
                guild_id INTEGER PRIMARY KEY,
                autorole_id INTEGER,
                mod_log_channel_id INTEGER,
                welcome_channel_id INTEGER,
                welcome_message TEXT NOT NULL DEFAULT 'Bem-vindo(a), {member}!',
                music_enabled INTEGER NOT NULL DEFAULT 1,
                moderation_enabled INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                moderator_id INTEGER NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """
        )
        await db.commit()

    async def get_guild_config(self, guild_id: int) -> GuildConfig:
        db = self._db
        await db.execute(
            "INSERT OR IGNORE INTO guild_configs (guild_id) VALUES (?)",
            (guild_id,),
        )
        await db.commit()
        row = await self.fetch_one(
            "SELECT * FROM guild_configs WHERE guild_id = ?",
            (guild_id,),
        )
        return GuildConfig(
            guild_id=row["guild_id"],
            autorole_id=row["autorole_id"],
            mod_log_channel_id=row["mod_log_channel_id"],
            welcome_channel_id=row["welcome_channel_id"],
            welcome_message=row["welcome_message"],
            music_enabled=bool(row["music_enabled"]),
            moderation_enabled=bool(row["moderation_enabled"]),
        )

    async def update_guild_config(self, guild_id: int, values: dict[str, Any]) -> None:
        await self.get_guild_config(guild_id)
        allowed = {
            "autorole_id",
            "mod_log_channel_id",
            "welcome_channel_id",
            "welcome_message",
            "music_enabled",
            "moderation_enabled",
        }
        fields = [field for field in values if field in allowed]
        if not fields:
            return

        assignments = ", ".join(f"{field} = ?" for field in fields)
        params = [values[field] for field in fields]
        params.append(guild_id)
        await self._db.execute(
            f"UPDATE guild_configs SET {assignments} WHERE guild_id = ?",
            params,
        )
        await self._db.commit()

    async def add_warning(
        self,
        guild_id: int,
        user_id: int,
        moderator_id: int,
        reason: str,
    ) -> None:
        await self._db.execute(
            """
            INSERT INTO warnings (guild_id, user_id, moderator_id, reason)
            VALUES (?, ?, ?, ?)
            """,
            (guild_id, user_id, moderator_id, reason),
        )
        await self._db.commit()

    async def list_warnings(self, guild_id: int, user_id: int) -> list[aiosqlite.Row]:
        return await self.fetch_all(
            """
            SELECT * FROM warnings
            WHERE guild_id = ? AND user_id = ?
            ORDER BY created_at DESC
            """,
            (guild_id, user_id),
        )

    async def fetch_one(self, query: str, params: tuple[Any, ...] = ()) -> aiosqlite.Row:
        async with self._db.execute(query, params) as cursor:
            row = await cursor.fetchone()
        if row is None:
            raise LookupError("Registro nao encontrado")
        return row

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] = (),
    ) -> list[aiosqlite.Row]:
        async with self._db.execute(query, params) as cursor:
            return await cursor.fetchall()

    @property
    def _db(self) -> aiosqlite.Connection:
        if self.conn is None:
            raise RuntimeError("Banco ainda nao foi conectado")
        return self.conn
