import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    discord_token: str
    web_admin_password: str
    web_host: str
    web_port: int
    database_path: Path

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv()
        token = os.getenv("DISCORD_TOKEN", "").strip()
        password = os.getenv("WEB_ADMIN_PASSWORD", "").strip()
        if not token:
            raise RuntimeError("DISCORD_TOKEN nao foi configurado no .env")
        if not password:
            raise RuntimeError("WEB_ADMIN_PASSWORD nao foi configurado no .env")

        return cls(
            discord_token=token,
            web_admin_password=password,
            web_host=os.getenv("WEB_HOST", "0.0.0.0"),
            web_port=int(os.getenv("PORT", os.getenv("WEB_PORT", "19071"))),
            database_path=Path(os.getenv("DATABASE_PATH", "data/bot.sqlite3")),
        )
