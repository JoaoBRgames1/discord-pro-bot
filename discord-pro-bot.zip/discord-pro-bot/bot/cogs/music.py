from __future__ import annotations

import asyncio
from dataclasses import dataclass

import discord
from discord import app_commands
from discord.ext import commands
import yt_dlp

from bot.client import ProBot


YDL_OPTIONS = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "default_search": "ytsearch",
}

FFMPEG_OPTIONS = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}


@dataclass
class Track:
    title: str
    url: str
    webpage_url: str


class GuildMusicState:
    def __init__(self) -> None:
        self.queue: asyncio.Queue[Track] = asyncio.Queue()
        self.current: Track | None = None


class MusicCog(commands.Cog):
    def __init__(self, bot: ProBot) -> None:
        self.bot = bot
        self.states: dict[int, GuildMusicState] = {}

    def get_state(self, guild_id: int) -> GuildMusicState:
        self.states.setdefault(guild_id, GuildMusicState())
        return self.states[guild_id]

    async def music_enabled(self, guild_id: int) -> bool:
        config = await self.bot.database.get_guild_config(guild_id)
        return config.music_enabled

    async def reply(self, interaction: discord.Interaction, message: str, ephemeral: bool = True) -> None:
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=ephemeral)
        else:
            await interaction.response.send_message(message, ephemeral=ephemeral)

    async def extract_track(self, query: str) -> Track:
        loop = asyncio.get_running_loop()

        def run() -> dict:
            with yt_dlp.YoutubeDL(YDL_OPTIONS) as ydl:
                return ydl.extract_info(query, download=False)

        data = await loop.run_in_executor(None, run)
        if "entries" in data:
            data = data["entries"][0]
        return Track(
            title=data.get("title", "Faixa sem titulo"),
            url=data["url"],
            webpage_url=data.get("webpage_url", query),
        )

    async def ensure_voice(self, interaction: discord.Interaction) -> discord.VoiceClient | None:
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            return None
        voice = interaction.user.voice
        if not voice or not voice.channel:
            await self.reply(interaction, "Entre em um canal de voz primeiro.")
            return None

        client = interaction.guild.voice_client
        if isinstance(client, discord.VoiceClient):
            if client.channel != voice.channel:
                await client.move_to(voice.channel)
            return client

        return await voice.channel.connect()

    async def play_next(self, guild: discord.Guild) -> None:
        voice = guild.voice_client
        if not isinstance(voice, discord.VoiceClient):
            return
        state = self.get_state(guild.id)
        if state.queue.empty():
            state.current = None
            return
        track = await state.queue.get()
        state.current = track
        source = discord.FFmpegPCMAudio(track.url, **FFMPEG_OPTIONS)
        voice.play(
            source,
            after=lambda _: asyncio.run_coroutine_threadsafe(self.play_next(guild), self.bot.loop),
        )

    @app_commands.command(name="play", description="Toca musica por busca ou URL.")
    @app_commands.guild_only()
    async def play(self, interaction: discord.Interaction, query: str) -> None:
        if not interaction.guild_id or not await self.music_enabled(interaction.guild_id):
            await interaction.response.send_message("Musica esta desativada neste servidor.", ephemeral=True)
            return
        await interaction.response.defer()
        voice = await self.ensure_voice(interaction)
        if not voice:
            return
        track = await self.extract_track(query)
        state = self.get_state(interaction.guild_id)
        await state.queue.put(track)
        if not voice.is_playing() and not voice.is_paused():
            await self.play_next(interaction.guild)
        await interaction.followup.send(f"Adicionado: **{track.title}**")

    @app_commands.command(name="pause", description="Pausa a musica atual.")
    @app_commands.guild_only()
    async def pause(self, interaction: discord.Interaction) -> None:
        voice = interaction.guild.voice_client if interaction.guild else None
        if isinstance(voice, discord.VoiceClient) and voice.is_playing():
            voice.pause()
            await interaction.response.send_message("Pausado.", ephemeral=True)
        else:
            await interaction.response.send_message("Nada tocando agora.", ephemeral=True)

    @app_commands.command(name="resume", description="Continua a musica pausada.")
    @app_commands.guild_only()
    async def resume(self, interaction: discord.Interaction) -> None:
        voice = interaction.guild.voice_client if interaction.guild else None
        if isinstance(voice, discord.VoiceClient) and voice.is_paused():
            voice.resume()
            await interaction.response.send_message("Continuando.", ephemeral=True)
        else:
            await interaction.response.send_message("Nada pausado agora.", ephemeral=True)

    @app_commands.command(name="skip", description="Pula a musica atual.")
    @app_commands.guild_only()
    async def skip(self, interaction: discord.Interaction) -> None:
        voice = interaction.guild.voice_client if interaction.guild else None
        if isinstance(voice, discord.VoiceClient) and voice.is_playing():
            voice.stop()
            await interaction.response.send_message("Pulando.", ephemeral=True)
        else:
            await interaction.response.send_message("Nada tocando agora.", ephemeral=True)

    @app_commands.command(name="queue", description="Mostra a fila de musicas.")
    @app_commands.guild_only()
    async def queue(self, interaction: discord.Interaction) -> None:
        state = self.get_state(interaction.guild_id)
        items = list(state.queue._queue)
        if not items and not state.current:
            await interaction.response.send_message("Fila vazia.", ephemeral=True)
            return
        lines = []
        if state.current:
            lines.append(f"Tocando agora: **{state.current.title}**")
        lines.extend(f"{index}. {track.title}" for index, track in enumerate(items[:10], start=1))
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

    @app_commands.command(name="stop", description="Para a musica e sai do canal.")
    @app_commands.guild_only()
    async def stop(self, interaction: discord.Interaction) -> None:
        voice = interaction.guild.voice_client if interaction.guild else None
        if isinstance(voice, discord.VoiceClient):
            await voice.disconnect(force=True)
            self.states.pop(interaction.guild_id, None)
            await interaction.response.send_message("Player encerrado.", ephemeral=True)
        else:
            await interaction.response.send_message("Nao estou em um canal de voz.", ephemeral=True)


async def setup(bot: ProBot) -> None:
    await bot.add_cog(MusicCog(bot))
