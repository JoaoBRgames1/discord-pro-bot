from datetime import timedelta

import discord
from discord import app_commands
from discord.ext import commands

from bot.client import ProBot


async def moderation_is_enabled(interaction: discord.Interaction) -> bool:
    bot = interaction.client
    if not isinstance(bot, ProBot) or not interaction.guild:
        return False
    config = await bot.database.get_guild_config(interaction.guild.id)
    return config.moderation_enabled


class ModerationCog(commands.Cog):
    def __init__(self, bot: ProBot) -> None:
        self.bot = bot

    async def _log(self, guild: discord.Guild, message: str) -> None:
        config = await self.bot.database.get_guild_config(guild.id)
        channel = guild.get_channel(config.mod_log_channel_id or 0)
        if isinstance(channel, discord.TextChannel):
            await channel.send(message)

    @app_commands.command(name="kick", description="Expulsa um membro.")
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.check(moderation_is_enabled)
    async def kick(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str = "Sem motivo informado",
    ) -> None:
        await member.kick(reason=reason)
        await interaction.response.send_message(f"{member.mention} foi expulso.", ephemeral=True)
        await self._log(interaction.guild, f"{member} foi expulso por {interaction.user}. Motivo: {reason}")

    @app_commands.command(name="ban", description="Bane um membro.")
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.check(moderation_is_enabled)
    async def ban(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str = "Sem motivo informado",
    ) -> None:
        await member.ban(reason=reason)
        await interaction.response.send_message(f"{member.mention} foi banido.", ephemeral=True)
        await self._log(interaction.guild, f"{member} foi banido por {interaction.user}. Motivo: {reason}")

    @app_commands.command(name="mute", description="Silencia temporariamente um membro.")
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.check(moderation_is_enabled)
    async def mute(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutes: app_commands.Range[int, 1, 40320],
        reason: str = "Sem motivo informado",
    ) -> None:
        until = discord.utils.utcnow() + timedelta(minutes=minutes)
        await member.timeout(until, reason=reason)
        await interaction.response.send_message(
            f"{member.mention} foi silenciado por {minutes} minuto(s).",
            ephemeral=True,
        )
        await self._log(interaction.guild, f"{member} silenciado por {interaction.user}. Motivo: {reason}")

    @app_commands.command(name="purge", description="Remove mensagens recentes do canal.")
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.check(moderation_is_enabled)
    async def purge(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 100],
    ) -> None:
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("Use este comando em um canal de texto.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"{len(deleted)} mensagem(ns) removida(s).", ephemeral=True)

    @app_commands.command(name="warn", description="Registra um aviso para um membro.")
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.check(moderation_is_enabled)
    async def warn(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str,
    ) -> None:
        await self.bot.database.add_warning(
            interaction.guild_id,
            member.id,
            interaction.user.id,
            reason,
        )
        await interaction.response.send_message(f"Aviso registrado para {member.mention}.", ephemeral=True)
        await self._log(interaction.guild, f"{member} recebeu aviso de {interaction.user}. Motivo: {reason}")

    @app_commands.command(name="warnings", description="Lista avisos de um membro.")
    @app_commands.guild_only()
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.check(moderation_is_enabled)
    async def warnings(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
    ) -> None:
        rows = await self.bot.database.list_warnings(interaction.guild_id, member.id)
        if not rows:
            await interaction.response.send_message("Esse membro nao possui avisos.", ephemeral=True)
            return
        lines = [
            f"#{row['id']} | {row['created_at']} | <@{row['moderator_id']}>: {row['reason']}"
            for row in rows[:10]
        ]
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

    async def cog_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        message = "Nao foi possivel executar esse comando."
        if isinstance(error, app_commands.MissingPermissions):
            message = "Voce nao tem permissao para executar esse comando."
        elif isinstance(error, app_commands.CheckFailure):
            message = "Moderacao esta desativada neste servidor."

        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)


async def setup(bot: ProBot) -> None:
    await bot.add_cog(ModerationCog(bot))
