import discord
from discord.ext import commands

from bot.client import ProBot


class AutomationCog(commands.Cog):
    def __init__(self, bot: ProBot) -> None:
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        config = await self.bot.database.get_guild_config(member.guild.id)

        if config.autorole_id:
            role = member.guild.get_role(config.autorole_id)
            if role:
                await member.add_roles(role, reason="Autorole configurado no painel")

        if config.welcome_channel_id:
            channel = member.guild.get_channel(config.welcome_channel_id)
            if isinstance(channel, discord.TextChannel):
                message = config.welcome_message.format(
                    member=member.mention,
                    server=member.guild.name,
                )
                await channel.send(message)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        config = await self.bot.database.get_guild_config(member.guild.id)
        channel = member.guild.get_channel(config.mod_log_channel_id or 0)
        if isinstance(channel, discord.TextChannel):
            await channel.send(f"{member} saiu do servidor.")

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User) -> None:
        config = await self.bot.database.get_guild_config(guild.id)
        channel = guild.get_channel(config.mod_log_channel_id or 0)
        if isinstance(channel, discord.TextChannel):
            await channel.send(f"{user} foi banido.")

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User) -> None:
        config = await self.bot.database.get_guild_config(guild.id)
        channel = guild.get_channel(config.mod_log_channel_id or 0)
        if isinstance(channel, discord.TextChannel):
            await channel.send(f"{user} foi desbanido.")


async def setup(bot: ProBot) -> None:
    await bot.add_cog(AutomationCog(bot))
