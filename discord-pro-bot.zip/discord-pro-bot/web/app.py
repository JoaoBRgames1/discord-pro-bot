from __future__ import annotations

from pathlib import Path
from typing import Annotated

import discord
from fastapi import Depends, FastAPI, Form, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from bot.client import ProBot
from bot.config import Settings
from bot.database import Database


def parse_optional_int(value: str) -> int | None:
    value = value.strip()
    return int(value) if value else None


def create_app(settings: Settings, database: Database, bot: ProBot) -> FastAPI:
    app = FastAPI(title="Discord Pro Bot Panel")
    project_root = Path(__file__).resolve().parents[1]
    templates = Jinja2Templates(directory=project_root / "templates")
    app.mount("/static", StaticFiles(directory=project_root / "static"), name="static")

    def require_auth(request: Request) -> None:
        if request.cookies.get("admin_auth") != settings.web_admin_password:
            raise HTTPException(status_code=303, headers={"Location": "/login"})

    @app.get("/login", response_class=HTMLResponse)
    async def login_page(request: Request) -> HTMLResponse:
        return templates.TemplateResponse("login.html", {"request": request})

    @app.post("/login")
    async def login(password: Annotated[str, Form()]) -> RedirectResponse:
        if password != settings.web_admin_password:
            return RedirectResponse("/login?erro=1", status_code=303)
        response = RedirectResponse("/", status_code=303)
        response.set_cookie(
            "admin_auth",
            settings.web_admin_password,
            httponly=True,
            samesite="lax",
        )
        return response

    @app.post("/logout")
    async def logout() -> RedirectResponse:
        response = RedirectResponse("/login", status_code=303)
        response.delete_cookie("admin_auth")
        return response

    @app.get("/", response_class=HTMLResponse)
    async def dashboard(
        request: Request,
        _: Annotated[None, Depends(require_auth)],
    ) -> HTMLResponse:
        guilds = sorted(bot.guilds, key=lambda guild: guild.name.lower())
        return templates.TemplateResponse(
            "dashboard.html",
            {"request": request, "bot": bot, "guilds": guilds},
        )

    @app.get("/guilds/{guild_id}", response_class=HTMLResponse)
    async def guild_settings(
        guild_id: int,
        request: Request,
        _: Annotated[None, Depends(require_auth)],
    ) -> HTMLResponse:
        guild = bot.get_guild(guild_id)
        if guild is None:
            raise HTTPException(status_code=404, detail="Servidor nao encontrado")
        config = await database.get_guild_config(guild_id)
        text_channels = [channel for channel in guild.channels if isinstance(channel, discord.TextChannel)]
        roles = [role for role in guild.roles if not role.managed and role.name != "@everyone"]
        return templates.TemplateResponse(
            "guild_settings.html",
            {
                "request": request,
                "guild": guild,
                "config": config,
                "text_channels": text_channels,
                "roles": roles,
            },
        )

    @app.post("/guilds/{guild_id}")
    async def save_guild_settings(
        guild_id: int,
        _: Annotated[None, Depends(require_auth)],
        autorole_id: Annotated[str, Form()] = "",
        mod_log_channel_id: Annotated[str, Form()] = "",
        welcome_channel_id: Annotated[str, Form()] = "",
        welcome_message: Annotated[str, Form()] = "Bem-vindo(a), {member}!",
        music_enabled: Annotated[str | None, Form()] = None,
        moderation_enabled: Annotated[str | None, Form()] = None,
    ) -> RedirectResponse:
        if bot.get_guild(guild_id) is None:
            raise HTTPException(status_code=404, detail="Servidor nao encontrado")
        await database.update_guild_config(
            guild_id,
            {
                "autorole_id": parse_optional_int(autorole_id),
                "mod_log_channel_id": parse_optional_int(mod_log_channel_id),
                "welcome_channel_id": parse_optional_int(welcome_channel_id),
                "welcome_message": welcome_message.strip() or "Bem-vindo(a), {member}!",
                "music_enabled": 1 if music_enabled == "on" else 0,
                "moderation_enabled": 1 if moderation_enabled == "on" else 0,
            },
        )
        return RedirectResponse(f"/guilds/{guild_id}?salvo=1", status_code=303)

    @app.get("/health")
    async def health() -> dict[str, str | int]:
        return {"status": "ok", "guilds": len(bot.guilds)}

    return app
